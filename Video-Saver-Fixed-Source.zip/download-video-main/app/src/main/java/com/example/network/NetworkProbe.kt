package com.example.network

import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.PlatformType
import com.example.data.model.ProbeResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object NetworkProbe {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "Unknown size"
        val k = 1024.0
        val sizes = arrayOf("B", "KB", "MB", "GB")
        val i = (Math.log(bytes.toDouble()) / Math.log(k)).toInt().coerceIn(0, 3)
        val value = bytes / Math.pow(k, i.toDouble())
        return String.format("%.2f %s", value, sizes[i])
    }

    private fun cleanEscapedUrl(raw: String): String {
        return raw.replace("\\/", "/")
            .replace("\\u0026", "&")
            .replace("\\u0025", "%")
            .replace("&amp;", "&")
    }

    private fun extractFbCdnFromToken(snapUrl: String): String {
        return try {
            if (!snapUrl.contains("token=")) return snapUrl
            val token = snapUrl.substringAfter("token=").substringBefore("&")
            val parts = token.split(".")
            if (parts.size >= 2) {
                val payload = parts[1]
                val decodedBytes = Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
                val json = JSONObject(String(decodedBytes, Charsets.UTF_8))
                json.optString("url", snapUrl)
            } else {
                snapUrl
            }
        } catch (_: Exception) {
            snapUrl
        }
    }

    suspend fun probe(url: String): ProbeResult = withContext(Dispatchers.IO) {
        val analysis = UrlAnalyzer.analyze(url)
        val targetUrl = analysis.normalizedUrl.ifEmpty { url.trim() }
        if (!analysis.isValid) {
            return@withContext ProbeResult(
                url = targetUrl,
                platform = analysis.platform,
                isDirectMedia = false,
                contentType = null,
                contentLength = null,
                formattedSize = "Invalid URL",
                filename = analysis.suggestedFilename,
                title = analysis.suggestedTitle,
                canDownloadDirectly = false,
                messageBn = analysis.guidanceBn.ifBlank { "সঠিক URL দিন।" },
                messageEn = analysis.guidanceEn.ifBlank { "Please enter a valid URL." }
            )
        }

        // 1. YouTube handling - 1-Click Direct MP4 Resolution
        if (analysis.platform == PlatformType.YOUTUBE) {
            var title = analysis.suggestedTitle
            var author = "YouTube Creator"
            var thumb: String? = null
            var directMp4Url: String? = null
            var qualityLabel = "720p HD MP4"

            // 1. Try local backend resolver
            val backendBaseUrl = BuildConfig.BACKEND_BASE_URL.trimEnd('/')
            if (backendBaseUrl.isBlank()) {
                return@withContext ProbeResult(
                    url = targetUrl, platform = PlatformType.YOUTUBE, isDirectMedia = false,
                    contentType = null, contentLength = null, formattedSize = "Backend not configured",
                    filename = analysis.suggestedFilename, title = title,
                    canDownloadDirectly = false,
                    messageBn = "YouTube ডাউনলোড সার্ভার এখনো কনফিগার করা হয়নি। Backend URL সেট করে নতুন APK তৈরি করুন।",
                    messageEn = "YouTube download backend is not configured. Set VIDEO_SAVER_BACKEND_URL and rebuild the APK."
                )
            }
            val backendEndpoints = listOf(
                "$backendBaseUrl/api/youtube-info?url=${URLEncoder.encode(targetUrl, "UTF-8")}"
            )
            for (endpoint in backendEndpoints) {
                try {
                    val bReq = Request.Builder()
                        .url(endpoint)
                        .header("User-Agent", "Mozilla/5.0 VideoSaver/2.0")
                        .build()
                    val bRes = client.newCall(bReq).execute()
                    if (bRes.isSuccessful) {
                        val bBody = bRes.body?.string() ?: ""
                        if (bBody.isNotEmpty()) {
                            val json = JSONObject(bBody)
                            if (json.optBoolean("success", false)) {
                                title = json.optString("title", title)
                                thumb = json.optString("thumbnail", thumb)
                                val candidate = json.optString("directDownloadUrl", "").ifBlank { json.optString("hdUrl", "") }
                                directMp4Url = when {
                                    candidate.startsWith("/") -> "$backendBaseUrl$candidate"
                                    candidate.startsWith("https://") -> candidate
                                    else -> null
                                }
                                val q = json.optString("quality", "")
                                if (q.isNotEmpty()) qualityLabel = "$q MP4"
                                if (!directMp4Url.isNullOrEmpty()) break
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // Fallback: oEmbed metadata if title/thumb not yet resolved
            if (thumb == null || title == analysis.suggestedTitle) {
                try {
                    val oEmbedUrl = "https://www.youtube.com/oembed?url=${URLEncoder.encode(targetUrl, "UTF-8")}&format=json"
                    val request = Request.Builder()
                        .url(oEmbedUrl)
                        .header("User-Agent", "Mozilla/5.0 VideoSaver/2.0")
                        .build()
                    val response = client.newCall(request).execute()
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrEmpty()) {
                            val json = JSONObject(body)
                            title = json.optString("title", title)
                            author = json.optString("author_name", author)
                            if (thumb == null) thumb = json.optString("thumbnail_url", null)
                        }
                    }
                } catch (_: Exception) {}
            }

            val finalUrl = directMp4Url
                ?: "$backendBaseUrl/api/youtube-stream?url=${URLEncoder.encode(targetUrl, "UTF-8")}"

            return@withContext ProbeResult(
                url = finalUrl,
                platform = PlatformType.YOUTUBE,
                isDirectMedia = true,
                contentType = "video/mp4",
                contentLength = null,
                formattedSize = qualityLabel,
                filename = analysis.suggestedFilename,
                title = title,
                thumbnailUrl = thumb,
                authorName = author,
                supportsRanges = true,
                canDownloadDirectly = true,
                messageBn = "ইউটিউব $qualityLabel ভিডিও সরাসরি প্রস্তুত হয়েছে! নিচের ডাউনলোড বাটনে চাপলে সরাসরি ফোনে সেভ হবে।",
                messageEn = "YouTube $qualityLabel video ready! Tap download to save directly."
            )
        }

        // 2. Facebook Video Direct Extraction
        if (analysis.platform == PlatformType.FACEBOOK) {
            var directMp4Url: String? = null
            var fbTitle = "Facebook Video"
            var fbThumb: String? = null
            var qualityLabel = "HD"

            // Method A: Direct resolver endpoint
            try {
                val resolverUrl = "https://api.siputzx.my.id/api/d/facebook?url=${URLEncoder.encode(targetUrl, "UTF-8")}"
                val req = Request.Builder()
                    .url(resolverUrl)
                    .header("User-Agent", "Mozilla/5.0 VideoSaver/2.0")
                    .build()
                val res = client.newCall(req).execute()
                if (res.isSuccessful) {
                    val body = res.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val root = JSONObject(body)
                        if (root.optBoolean("status", false)) {
                            val data = root.optJSONObject("data")
                            if (data != null) {
                                fbTitle = data.optString("title", fbTitle).ifEmpty { "Facebook Video" }
                                fbThumb = data.optString("thumbnail", null)
                                val downloads = data.optJSONArray("downloads")
                                if (downloads != null && downloads.length() > 0) {
                                    val firstItem = downloads.getJSONObject(0)
                                    val snapUrl = firstItem.optString("url", "")
                                    qualityLabel = firstItem.optString("quality", "HD")
                                    if (snapUrl.isNotEmpty()) {
                                        // Extract direct FBCDN url from token or use snapUrl
                                        directMp4Url = extractFbCdnFromToken(snapUrl)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {}

            // Method B: Fallback HTML scraping
            if (directMp4Url == null) {
                try {
                    val fbRequest = Request.Builder()
                        .url(targetUrl)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                        .build()
                    val fbResponse = client.newCall(fbRequest).execute()
                    if (fbResponse.isSuccessful) {
                        val html = fbResponse.body?.string() ?: ""

                        val hdPattern = Pattern.compile("\"(?:browser_native_hd_url|playable_url_quality_hd|hd_src)\"\\s*:\\s*\"([^\"]+)\"")
                        val hdMatcher = hdPattern.matcher(html)
                        if (hdMatcher.find()) {
                            directMp4Url = cleanEscapedUrl(hdMatcher.group(1))
                            qualityLabel = "HD"
                        } else {
                            val sdPattern = Pattern.compile("\"(?:browser_native_sd_url|playable_url|sd_src)\"\\s*:\\s*\"([^\"]+)\"")
                            val sdMatcher = sdPattern.matcher(html)
                            if (sdMatcher.find()) {
                                directMp4Url = cleanEscapedUrl(sdMatcher.group(1))
                                qualityLabel = "SD"
                            }
                        }

                        val thumbPattern = Pattern.compile("<meta\\s+(?:property|name)=\"og:image\"\\s+content=\"([^\"]+)\"")
                        val thumbMatcher = thumbPattern.matcher(html)
                        if (thumbMatcher.find()) {
                            fbThumb = cleanEscapedUrl(thumbMatcher.group(1))
                        }

                        val titlePattern = Pattern.compile("<meta\\s+(?:property|name)=\"og:title\"\\s+content=\"([^\"]+)\"")
                        val titleMatcher = titlePattern.matcher(html)
                        if (titleMatcher.find()) {
                            fbTitle = titleMatcher.group(1).replace("&amp;", "&").replace("&quot;", "\"")
                        }
                    }
                } catch (_: Exception) {}
            }

            val finalDownloadUrl = directMp4Url ?: targetUrl
            val isDirectResolved = directMp4Url != null

            return@withContext ProbeResult(
                url = finalDownloadUrl,
                platform = PlatformType.FACEBOOK,
                isDirectMedia = true,
                contentType = "video/mp4",
                contentLength = null,
                formattedSize = "$qualityLabel MP4",
                filename = "facebook_${System.currentTimeMillis() % 10000}.mp4",
                title = fbTitle,
                thumbnailUrl = fbThumb,
                authorName = "Facebook Video ($qualityLabel)",
                supportsRanges = true,
                canDownloadDirectly = isDirectResolved,
                messageBn = if (isDirectResolved)
                    "ফেসবুক $qualityLabel ভিডিও সরাসরি প্রস্তুত হয়েছে! নিচের 'ভিডিও ডাউনলোড করুন' বাটনে চাপলে সরাসরি ফোনে সেভ হবে।"
                else
                    "ফেসবুক ভিডিও পেজ সনাক্ত হয়েছে। ডাউনলোডের জন্য লিঙ্কটি ব্রাউজারে খুলুন বা সরাসরি সেভ করুন।",
                messageEn = if (isDirectResolved)
                    "Facebook $qualityLabel video ready! Tap 'Download Video' to save directly to Downloads."
                else
                    "Facebook video stream ready."
            )
        }

        // 3. Pinterest Direct Video Extraction
        if (analysis.platform == PlatformType.PINTEREST) {
            var directPinMp4: String? = null
            var pinTitle = "Pinterest Video"
            var pinThumb: String? = null

            try {
                // Fetch page (OkHttp automatically follows 301/302 redirects from pin.it to pinterest.com/pin/...)
                val req = Request.Builder()
                    .url(targetUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .build()
                val res = client.newCall(req).execute()
                val finalUrl = res.request.url.toString()
                val html = if (res.isSuccessful) res.body?.string() ?: "" else ""

                // 1. Extract Pin ID from finalUrl or HTML
                var pinId: String? = null
                val idMatchUrl = Pattern.compile("/pin/(\\d+)").matcher(finalUrl)
                if (idMatchUrl.find()) {
                    pinId = idMatchUrl.group(1)
                } else if (html.isNotEmpty()) {
                    val idMatchHtml = Pattern.compile("/pin/(\\d+)").matcher(html)
                    if (idMatchHtml.find()) {
                        pinId = idMatchHtml.group(1)
                    }
                }

                // 2. Try official Pinterest widget API
                if (!pinId.isNullOrEmpty()) {
                    try {
                        val widgetUrl = "https://widgets.pinterest.com/v3/pidgets/pins/info/?pin_ids=$pinId"
                        val wReq = Request.Builder()
                            .url(widgetUrl)
                            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                            .build()
                        val wRes = client.newCall(wReq).execute()
                        if (wRes.isSuccessful) {
                            val wBody = wRes.body?.string() ?: ""
                            val wJson = JSONObject(wBody)
                            val dataArr = wJson.optJSONArray("data")
                            if (dataArr != null && dataArr.length() > 0) {
                                val pinObj = dataArr.getJSONObject(0)
                                val desc = pinObj.optString("description", "")
                                if (desc.isNotEmpty()) pinTitle = desc

                                val images = pinObj.optJSONObject("images")
                                if (images != null) {
                                    val img564 = images.optJSONObject("564x")
                                    val img236 = images.optJSONObject("236x")
                                    pinThumb = img564?.optString("url") ?: img236?.optString("url")
                                }

                                val videos = pinObj.optJSONObject("videos")
                                if (videos != null) {
                                    val vList = videos.optJSONObject("video_list")
                                    if (vList != null) {
                                        val v720 = vList.optJSONObject("V_720P")
                                        val vExp7 = vList.optJSONObject("V_EXP7")
                                        val vHls = vList.optJSONObject("V_HLSV4")
                                        if (v720 != null && v720.has("url")) {
                                            directPinMp4 = v720.optString("url")
                                        } else if (vExp7 != null && vExp7.has("url")) {
                                            directPinMp4 = vExp7.optString("url")
                                        } else if (vHls != null && vHls.has("url")) {
                                            val hlsUrl = vHls.optString("url")
                                            directPinMp4 = hlsUrl.replace("/hls/", "/720p/").replace(".m3u8", ".mp4")
                                        }
                                    }
                                }

                                // Handle Story Pin / Idea Pin videos inside widget body
                                if (directPinMp4 == null) {
                                    val cleanWBody = wBody.replace("\\/", "/")
                                    val wMp4Matcher = Pattern.compile("https://[a-zA-Z0-9.-]*pinimg\\.com/videos/[^\"'<> ]+\\.mp4").matcher(cleanWBody)
                                    if (wMp4Matcher.find()) {
                                        directPinMp4 = cleanEscapedUrl(wMp4Matcher.group(0))
                                    } else {
                                        val wHlsMatcher = Pattern.compile("https://[a-zA-Z0-9.-]*pinimg\\.com/videos/[^\"'<> ]+\\.m3u8").matcher(cleanWBody)
                                        if (wHlsMatcher.find()) {
                                            val raw = wHlsMatcher.group(0)
                                            directPinMp4 = if (raw.contains("/iht/hls/")) {
                                                raw.replace("/hls/", "/expMp4/").replace(".m3u8", "_720w.mp4")
                                            } else {
                                                raw.replace("/hls/", "/720p/").replace(".m3u8", ".mp4")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }

                // 3. Fallback: Parse HTML for pinimg video URLs
                if (directPinMp4 == null && html.isNotEmpty()) {
                    val cleanHtml = html.replace("\\/", "/")
                    val anyMp4Pattern = Pattern.compile("https://[a-zA-Z0-9.-]*pinimg\\.com/videos/[^\"'<> ]+\\.mp4")
                    val anyMatcher = anyMp4Pattern.matcher(cleanHtml)
                    if (anyMatcher.find()) {
                        directPinMp4 = cleanEscapedUrl(anyMatcher.group(0))
                    } else {
                        val m3u8Pattern = Pattern.compile("https://[a-zA-Z0-9.-]*pinimg\\.com/videos/[^\"'<> ]+\\.m3u8")
                        val m3u8Matcher = m3u8Pattern.matcher(cleanHtml)
                        if (m3u8Matcher.find()) {
                            val rawM3u8 = m3u8Matcher.group(0)
                            directPinMp4 = if (rawM3u8.contains("/iht/hls/")) {
                                rawM3u8.replace("/hls/", "/expMp4/").replace(".m3u8", "_720w.mp4")
                            } else {
                                rawM3u8.replace("/hls/", "/720p/").replace(".m3u8", ".mp4")
                            }
                        }
                    }

                    if (pinTitle == "Pinterest Video") {
                        val titlePattern = Pattern.compile("\"seoTitle\"\\s*:\\s*\"([^\"]+)\"")
                        val titleMatcher = titlePattern.matcher(html)
                        if (titleMatcher.find()) {
                            pinTitle = cleanEscapedUrl(titleMatcher.group(1))
                        }
                    }
                    if (pinThumb == null) {
                        val thumbPattern = Pattern.compile("\"imageLargeUrl\"\\s*:\\s*\"([^\"]+)\"")
                        val thumbMatcher = thumbPattern.matcher(html)
                        if (thumbMatcher.find()) {
                            pinThumb = cleanEscapedUrl(thumbMatcher.group(1))
                        }
                    }
                }
            } catch (_: Exception) {}

            val isResolved = directPinMp4 != null
            return@withContext ProbeResult(
                url = directPinMp4 ?: targetUrl,
                platform = PlatformType.PINTEREST,
                isDirectMedia = true,
                contentType = "video/mp4",
                contentLength = null,
                formattedSize = if (isResolved) "720p HD MP4" else "Pinterest Video",
                filename = "pinterest_${System.currentTimeMillis() % 10000}.mp4",
                title = pinTitle,
                thumbnailUrl = pinThumb,
                authorName = "Pinterest Video (720p)",
                supportsRanges = true,
                canDownloadDirectly = isResolved,
                messageBn = if (isResolved)
                    "পিন্টারেস্ট HD ভিডিও সরাসরি প্রস্তুত হয়েছে! নিচের 'ভিডিও ডাউনলোড করুন' বাটনে চাপলে সরাসরি ফোনে সেভ হবে।"
                else
                    "পিন্টারেস্ট ভিডিও লিঙ্ক পাওয়া গেছে! ডাউনলোড বাটনে চাপুন।",
                messageEn = if (isResolved)
                    "Pinterest HD video ready! Tap 'Download Video' to save directly to Downloads."
                else
                    "Pinterest video stream detected."
            )
        }

        // 4. Network probe for other links
        var contentType: String? = null
        var contentLength: Long? = null
        var supportsRanges = false
        var serverFilename: String? = null

        try {
            var request = Request.Builder()
                .url(targetUrl)
                .head()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) VideoSaver/2.0")
                .header("Accept", "*/*")
                .build()

            var response = client.newCall(request).execute()

            if (response.code == 405 || response.code == 403 || response.code == 501) {
                request = Request.Builder()
                    .url(targetUrl)
                    .get()
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) VideoSaver/2.0")
                    .header("Range", "bytes=0-1")
                    .build()
                response = client.newCall(request).execute()
            }

            contentType = response.header("Content-Type")
            val lengthHeader = response.header("Content-Length")
            val contentRange = response.header("Content-Range")
            val acceptRanges = response.header("Accept-Ranges")
            val contentDisposition = response.header("Content-Disposition")

            if (lengthHeader != null) {
                contentLength = lengthHeader.toLongOrNull()
            } else if (contentRange != null) {
                val totalStr = contentRange.substringAfterLast("/")
                contentLength = totalStr.toLongOrNull()
            }

            if (acceptRanges?.equals("bytes", ignoreCase = true) == true) {
                supportsRanges = true
            }

            if (contentDisposition != null && contentDisposition.contains("filename=")) {
                serverFilename = contentDisposition.substringAfter("filename=")
                    .trim('\"', '\'', ' ', ';')
            }
        } catch (e: Exception) {
            return@withContext ProbeResult(
                url = targetUrl,
                platform = analysis.platform,
                isDirectMedia = analysis.mediaExtension != null,
                contentType = null,
                contentLength = null,
                formattedSize = "Unknown",
                filename = analysis.suggestedFilename,
                title = analysis.suggestedTitle,
                canDownloadDirectly = analysis.mediaExtension != null,
                messageBn = "নেটওয়ার্ক সংযোগ ত্রুটি (${e.localizedMessage ?: "timeout"})। ইন্টারনেট সংযোগ চেক করে আবার চেষ্টা করুন।",
                messageEn = "Network probe failed: ${e.localizedMessage ?: "timeout"}. Check connection and retry."
            )
        }

        val cleanMime = contentType?.lowercase() ?: ""
        val isVideoMime = cleanMime.startsWith("video/")

        val isHtml = cleanMime.contains("text/html")
        val finalFilename = serverFilename ?: analysis.suggestedFilename

        if (isHtml) {
            return@withContext ProbeResult(
                url = targetUrl,
                platform = analysis.platform,
                isDirectMedia = false,
                contentType = cleanMime,
                contentLength = contentLength,
                formattedSize = contentLength?.let { formatBytes(it) } ?: "HTML Page",
                filename = finalFilename,
                title = analysis.suggestedTitle,
                supportsRanges = supportsRanges,
                canDownloadDirectly = false,
                messageBn = "এই লিঙ্কটি একটি সাধারণ ওয়েব পেজ। সরাসরি ভিডিও সেভ করতে এর আসল .mp4 লিঙ্ক প্রয়োজন।",
                messageEn = "This URL returned an HTML webpage rather than a media stream. Direct media link required."
            )
        }

        val canDownload = isVideoMime || analysis.mediaExtension != null
        val formattedSize = contentLength?.let { formatBytes(it) } ?: "Stream Size"

        return@withContext ProbeResult(
            url = targetUrl,
            platform = if (canDownload) PlatformType.DIRECT else analysis.platform,
            isDirectMedia = canDownload,
            contentType = cleanMime.ifEmpty { "application/octet-stream" },
            contentLength = contentLength,
            formattedSize = formattedSize,
            filename = finalFilename,
            title = analysis.suggestedTitle,
            supportsRanges = supportsRanges,
            canDownloadDirectly = canDownload,
            messageBn = if (canDownload)
                "বৈধ ডিরেক্ট ভিডিও ফাইল পাওয়া গেছে! 'ভিডিও ডাউনলোড করুন' বাটনে চাপ দিয়ে ফোনে সেভ করুন।"
            else
                "সার্ভার সাড়া দিয়েছে কিন্তু রেসপন্সটি ভিডিও টাইপ নয়।",
            messageEn = if (canDownload)
                "Valid direct video stream confirmed! Tap 'Download Video' to save to your Android device."
            else
                "Server responded, but content-type is not recognized as a video."
        )
    }
}
