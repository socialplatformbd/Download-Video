package com.example.network

import com.example.data.model.PlatformType
import com.example.data.model.UrlAnalysis
import java.net.URI

object UrlAnalyzer {
    private val VIDEO_EXTENSIONS = listOf(".mp4", ".webm", ".mkv", ".mov", ".m4v", ".ogv", ".3gp")
    private val UNSAFE_SCHEMES = listOf("javascript", "data", "file", "vbscript", "about", "content", "blob")

    fun analyze(rawInput: String): UrlAnalysis {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return UrlAnalysis(
                isValid = false,
                rawUrl = "",
                platform = PlatformType.OTHER,
                limitationReason = "URL cannot be empty.",
                guidanceBn = "অনুগ্রহ করে একটি সঠিক ভিডিও লিংক (https:// সহ) দিন।",
                guidanceEn = "Please enter a valid video URL starting with https://"
            )
        }

        // Scheme validation
        val scheme = try {
            val uri = URI(trimmed)
            uri.scheme?.lowercase() ?: ""
        } catch (_: Exception) {
            val idx = trimmed.indexOf(":")
            if (idx != -1) trimmed.substring(0, idx).lowercase() else ""
        }

        if (UNSAFE_SCHEMES.contains(scheme)) {
            return UrlAnalysis(
                isValid = false,
                rawUrl = trimmed,
                platform = PlatformType.OTHER,
                limitationReason = "Unsafe scheme '$scheme:' is blocked for security.",
                guidanceBn = "নিরাপত্তার স্বার্থে '$scheme:' প্রোটোকল ব্লক করা হয়েছে। শুধুমাত্র http/https ব্যবহার করুন।",
                guidanceEn = "Security policy: '$scheme:' protocol is blocked. Only http and https are permitted."
            )
        }

        val uri = try {
            URI(trimmed)
        } catch (_: Exception) {
            return UrlAnalysis(
                isValid = false,
                rawUrl = trimmed,
                platform = PlatformType.OTHER,
                limitationReason = "Malformed URL format.",
                guidanceBn = "লিংকের ফরম্যাট সঠিক নয়। ডোমেইন নাম ও https:// যাচাই করুন।",
                guidanceEn = "Malformed URL format. Make sure it includes https:// and a valid domain."
            )
        }

        val protocol = uri.scheme?.lowercase()
        if (protocol != "http" && protocol != "https") {
            return UrlAnalysis(
                isValid = false,
                rawUrl = trimmed,
                platform = PlatformType.OTHER,
                limitationReason = "Unsupported protocol '$protocol'.",
                guidanceBn = "শুধুমাত্র HTTP এবং HTTPS প্রোটোকল সমর্থিত।",
                guidanceEn = "Only standard HTTP and HTTPS protocols are supported."
            )
        }

        val host = uri.host?.lowercase() ?: ""
        if (host.isBlank() || uri.rawUserInfo != null) {
            return UrlAnalysis(
                isValid = false,
                rawUrl = trimmed,
                platform = PlatformType.OTHER,
                limitationReason = "A valid hostname is required; embedded credentials are not allowed.",
                guidanceBn = "সঠিক ওয়েবসাইটের ডোমেইনসহ লিংক দিন। URL-এর মধ্যে Username বা Password দেওয়া যাবে না।",
                guidanceEn = "Enter a URL with a valid hostname. Embedded usernames and passwords are not allowed."
            )
        }
        val path = uri.path ?: ""

        // Check if direct video file
        var detectedExt: String? = null
        val lowerPath = path.lowercase()
        for (ext in VIDEO_EXTENSIONS) {
            if (lowerPath.endsWith(ext) || lowerPath.contains("$ext?")) {
                detectedExt = ext
                break
            }
        }

        // Extract base filename
        val lastSegment = path.substringAfterLast("/").substringBefore("?")
        var baseFilename = if (lastSegment.isNotBlank()) lastSegment else "video"
        for (ext in VIDEO_EXTENSIONS) {
            if (baseFilename.lowercase().endsWith(ext)) {
                baseFilename = baseFilename.substring(0, baseFilename.length - ext.length)
                break
            }
        }
        val safeBase = baseFilename.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(30).ifEmpty { "video" }
        val extToUse = detectedExt ?: ".mp4"
        val suggestedFilename = "$safeBase$extToUse"

        // 1. YouTube Detection
        if (host == "youtube.com" || host.endsWith(".youtube.com") || host == "youtu.be") {
            val videoId = when {
                host == "youtu.be" -> path.trimStart('/').substringBefore('?').substringBefore('&')
                path.contains("/watch") -> uri.query?.split("&")?.firstOrNull { it.startsWith("v=") }?.substringAfter("v=")
                path.contains("/shorts/") -> path.substringAfter("/shorts/").substringBefore('?').substringBefore('/')
                path.contains("/embed/") -> path.substringAfter("/embed/").substringBefore('?').substringBefore('/')
                else -> null
            }
            return UrlAnalysis(
                isValid = true,
                rawUrl = trimmed,
                normalizedUrl = trimmed,
                platform = PlatformType.YOUTUBE,
                isDirectMediaCandidate = false,
                videoId = videoId,
                suggestedTitle = if (videoId != null) "YouTube Video ($videoId)" else "YouTube Link",
                suggestedFilename = "youtube_${videoId ?: "video"}.mp4",
                limitationReason = "YouTube video stream detected.",
                guidanceBn = "ইউটিউব ভিডিও সনাক্ত হয়েছে! প্রিভিউ দেখতে এবং ডাউনলোড অপশন পেতে 'যাচাই করুন' চাপুন।",
                guidanceEn = "YouTube video detected! Tap 'Validate Link' for preview and download options."
            )
        }

        // 2. Facebook Detection
        if (host == "facebook.com" || host.endsWith(".facebook.com") || host == "fb.watch") {
            return UrlAnalysis(
                isValid = true,
                rawUrl = trimmed,
                normalizedUrl = trimmed,
                platform = PlatformType.FACEBOOK,
                isDirectMediaCandidate = false,
                suggestedTitle = "Facebook Video",
                suggestedFilename = "facebook_video.mp4",
                limitationReason = "Facebook video post detected.",
                guidanceBn = "ফেসবুক ভিডিও পেজ সনাক্ত হয়েছে। সরাসরি HD MP4 ডাউনলোডের জন্য 'যাচাই করুন' চাপুন।",
                guidanceEn = "Facebook post detected. Tap 'Validate Link' to extract direct HD MP4 video."
            )
        }

        // 3. Pinterest Detection
        if (host == "pinterest.com" || host.endsWith(".pinterest.com") || host == "pin.it") {
            return UrlAnalysis(
                isValid = true,
                rawUrl = trimmed,
                normalizedUrl = trimmed,
                platform = PlatformType.PINTEREST,
                isDirectMediaCandidate = true,
                suggestedTitle = "Pinterest Video",
                suggestedFilename = "pinterest_video.mp4",
                limitationReason = "Pinterest video pin detected.",
                guidanceBn = "পিন্টারেস্ট ভিডিও সনাক্ত হয়েছে! সরাসরি HD MP4 ভিডিও পেতে 'যাচাই করুন' চাপুন।",
                guidanceEn = "Pinterest video detected! Tap 'Validate Link' to extract direct HD MP4."
            )
        }

        // 4. Direct Media File
        if (detectedExt != null) {
            return UrlAnalysis(
                isValid = true,
                rawUrl = trimmed,
                normalizedUrl = trimmed,
                platform = PlatformType.DIRECT,
                isDirectMediaCandidate = true,
                mediaExtension = detectedExt,
                suggestedTitle = "$safeBase$detectedExt",
                suggestedFilename = suggestedFilename,
                guidanceBn = "ডিরেক্ট ভিডিও ফাইল সনাক্ত হয়েছে! 'যাচাই করুন' চাপলে ফাইলের সাইজ ও ডিটেইলস জানা যাবে।",
                guidanceEn = "Direct media file confirmed! Tap 'Validate Link' to inspect file headers and download."
            )
        }

        // 5. Other general web URL
        return UrlAnalysis(
            isValid = true,
            rawUrl = trimmed,
            normalizedUrl = trimmed,
            platform = PlatformType.OTHER,
            isDirectMediaCandidate = false,
            suggestedTitle = "${host.take(20)} Link",
            suggestedFilename = suggestedFilename,
            guidanceBn = "সার্ভারের সাথে সংযোগ করে ভিডিও স্ট্রীম পরীক্ষা করতে 'যাচাই করুন' চাপুন।",
            guidanceEn = "Tap 'Validate Link' to probe server headers and test if this is a downloadable stream."
        )
    }
}
