package com.example

import com.example.data.model.PlatformType
import com.example.network.UrlAnalyzer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun recognizesSupportedYouTubeLinks() {
        val result = UrlAnalyzer.analyze("https://www.youtube.com/watch?v=abcdefghijk")
        assertTrue(result.isValid)
        assertEquals(PlatformType.YOUTUBE, result.platform)
        assertFalse(result.isDirectMediaCandidate)
    }

    @Test
    fun rejectsLookalikeYouTubeDomain() {
        val result = UrlAnalyzer.analyze("https://notyoutube.com/watch?v=abcdefghijk")
        assertTrue(result.isValid)
        assertEquals(PlatformType.OTHER, result.platform)
        assertFalse(result.isDirectMediaCandidate)
    }

    @Test
    fun recognizesDirectMp4ByPathExtension() {
        val result = UrlAnalyzer.analyze("https://cdn.example.org/media/sample.mp4?token=abc")
        assertTrue(result.isValid)
        assertEquals(PlatformType.DIRECT, result.platform)
        assertTrue(result.isDirectMediaCandidate)
    }

    @Test
    fun doesNotAssumeEveryWebPageIsAVideo() {
        val result = UrlAnalyzer.analyze("https://example.org/watch")
        assertTrue(result.isValid)
        assertEquals(PlatformType.OTHER, result.platform)
        assertFalse(result.isDirectMediaCandidate)
    }

    @Test
    fun rejectsUnsafeSchemes() {
        val result = UrlAnalyzer.analyze("javascript:alert(1)")
        assertFalse(result.isValid)
    }
}
