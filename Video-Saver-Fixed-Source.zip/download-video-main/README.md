# Video Saver

Android application and Node.js/PWA backend.

## Backend deployment

Deploy the repository root as a Node.js service with Python 3 available. Build command: `npm ci`. Start command: `npm start`. The bundled yt-dlp Python zipapp is launched through `python3`, so executable file permissions are not required. The server binds to the platform-provided `PORT`. Health check: `/healthz`. Set `ALLOWED_ORIGINS` only when hosting the PWA on a separate origin.

The backend only accepts valid HTTPS YouTube URLs for its YouTube extraction endpoints. It applies per-IP rate limiting and limits concurrent yt-dlp streams. Review platform terms and copyright rules before downloading content.

## Android APK build

The GitHub Actions workflow builds a debug APK. Set repository variable `VIDEO_SAVER_BACKEND_URL` to the deployed backend base URL (for example `https://your-service.onrender.com`) before running the workflow. If it is unset, YouTube downloads are disabled with an explanatory message; no emulator-only localhost URL is used.

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
