# Video Saver — Audit ও সংশোধন নোট

## এই সংস্করণে সংশোধিত

1. Android-এর YouTube Backend URL আর Emulator-only `10.0.2.2` বা `localhost`-এ স্থির করা নেই। `VIDEO_SAVER_BACKEND_URL` দিয়ে Build Config-এ আসল HTTPS Backend URL দিতে হবে। URL না থাকলে অ্যাপ এখন YouTube download-কে ভুলভাবে ready দেখায় না; স্পষ্ট configuration message দেখায়।
2. Node server এখন Hosting Platform-এর `PORT` ব্যবহার করে।
3. yt-dlp Python zipapp-কে `python3` দিয়ে চালানো হয়; ZIP-এর executable bit-এর ওপর নির্ভর করে না।
4. YouTube API-তে HTTPS YouTube URL validation, request rate limit এবং concurrent stream limit যোগ হয়েছে।
5. Static server এখন কেবল নির্দিষ্ট app shell ও icon ফাইল পরিবেশন করে। `server.js`, `.env`, package files, source tree ও embedded ZIP সরাসরি serve করে না।
6. Cross-origin request default-এ বন্ধ। আলাদা origin-এ PWA থাকলে `ALLOWED_ORIGINS`-এ নির্দিষ্ট origin যোগ করতে হবে।
7. Upstream extractor CDN hostname যাচাই করা হয়।
8. Server-side URL/Path handling ও unsupported HTTP method handling শক্ত করা হয়েছে।
9. Android URL parser-এ lookalike host, embedded credentials এবং unsupported scheme যাচাই করা হয়েছে। সাধারণ webpage-কে আর স্বয়ংক্রিয়ভাবে video ধরা হয় না।
10. Download stream-এর connection error, empty response এবং incomplete byte count যাচাই করা হয়। Temporary file নাম collision এড়াতে timestamp ব্যবহার করা হয় এবং সফল MediaStore copy-এর পর temporary file সরানো হয়।
11. MediaStore copy ব্যর্থ হলে অসম্পূর্ণ MediaStore entry মুছে ফেলার চেষ্টা করা হয়।
12. DownloadManager history-তে enqueue করার সঙ্গে সঙ্গে `completed` না লিখে `queued_dm` লেখা হয়।
13. App language, filename prefix, auto-validate ও download method SharedPreferences-এ সংরক্ষণ করা হয়।
14. Gradle debug build-এর জন্য অনুপস্থিত repository `debug.keystore` বাধ্যতামূলক নয়; Gradle-এর default debug signing ব্যবহৃত হয়।
15. PWA manifest-এ প্রকৃত 192px ও 512px PNG icon দেওয়া হয়েছে এবং Service Worker shell cache উন্নত করা হয়েছে।
16. GitHub Actions workflow যোগ করা হয়েছে: Android debug APK build এবং backend dependency/syntax check।
17. Render Blueprint (`render.yaml`) ও deployment নির্দেশনা যোগ করা হয়েছে।
18. URL Analyzer-এর জন্য unit test যোগ করা হয়েছে।

## এই পরিবেশে যাচাই করা হয়েছে

- `node --check server.js` — সফল
- `node --check sw.js` — সফল
- `npm ci --dry-run --offline` — lockfile consistency check সফল
- Node server `/healthz` — HTTP 200
- Invalid lookalike YouTube domain — HTTP 400
- Source file exposure (`/server.js`, `/.env.example`) — HTTP 404
- Configured CORS allowed origin — HTTP 200; blocked origin — HTTP 403
- Unsupported POST method — HTTP 405
- `Models.kt` ও `UrlAnalyzer.kt` Kotlin compile — সফল
- URL Analyzer-এর ৬টি smoke test — সফল

## এখনো বাস্তব Build/Device Test প্রয়োজন

এই কাজের পরিবেশে Android SDK/Gradle build runner নেই। তাই সম্পূর্ণ Android APK compilation, APK installation, Samsung/Android বাস্তব ডিভাইসে download, Render deployment, YouTube/Facebook/Pinterest-এর live extraction এবং MediaStore/DownloadManager-এর end-to-end পরীক্ষা এখানে সম্পন্ন হয়নি। GitHub Actions-এ APK workflow চালিয়ে Build Log যাচাই করতে হবে।

## অবশিষ্ট সীমাবদ্ধতা

- YouTube extraction yt-dlp ও তৃতীয়-পক্ষের upstream service/সাইট পরিবর্তনের ওপর নির্ভরশীল; কোনো নির্দিষ্ট ভিডিও সবসময় ডাউনলোড হবে—এ নিশ্চয়তা দেওয়া যায় না।
- Facebook ও Pinterest extraction-এ তৃতীয়-পক্ষ resolver ব্যবহৃত হয়; সেগুলোর API বদলালে extraction ব্যর্থ হতে পারে।
- Stream mode এখনো অ্যাপের চলমান process-এর মধ্যে চলে; পূর্ণ background reliability, WorkManager/Foreground Service, resume ও retry পরবর্তী কাজ।
- DownloadManager mode-এ এখন queued status সঠিকভাবে দেখানো হয়; system download completion-এর পর Room history স্বয়ংক্রিয়ভাবে update করার receiver এখনো যোগ করা হয়নি।
- Download করা কনটেন্টের মালিকানা, অনুমতি এবং সংশ্লিষ্ট প্ল্যাটফর্মের Terms of Service মেনে ব্যবহার করতে হবে।

## Build configuration

GitHub Repository → Settings → Secrets and variables → Actions → Variables-এ `VIDEO_SAVER_BACKEND_URL` নামে Render Backend-এর HTTPS base URL যোগ করতে হবে। তারপর Actions → Build Android APK → Run workflow চালাতে হবে। Backend deploy-এর পর Render-এর `ALLOWED_ORIGINS` প্রয়োজন হলে সেট করতে হবে; একই Node service-এ PWA পরিবেশন করলে এটি খালি রাখা যায়।
