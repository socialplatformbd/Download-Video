const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { createDecipheriv } = require('crypto');

process.on('uncaughtException', (err) => {
  console.error('[Uncaught Exception]', err.message);
});
process.on('unhandledRejection', (err) => {
  console.error('[Unhandled Rejection]', err);
});

const PORT = Number.parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const MAX_ACTIVE_STREAMS = Number.parseInt(process.env.MAX_ACTIVE_STREAMS || '2', 10);
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 20;
const requestCounts = new Map();
let activeStreams = 0;
async function fetchJson(url, options = {}, timeoutMs = 10000) {
  const response = await fetch(url, { ...options, signal: AbortSignal.timeout(timeoutMs) });
  if (!response.ok) throw new Error(`Upstream HTTP ${response.status}`);
  return response.json();
}


function isValidYouTubeUrl(value) {
  try {
    const u = new URL(value);
    const host = u.hostname.toLowerCase();
    const allowed = host === 'youtu.be' || host === 'youtube.com' || host.endsWith('.youtube.com');
    return allowed && u.protocol === 'https:' && !!extractYouTubeVideoId(value);
  } catch (_) { return false; }
}

function clientAllowed(req) {
  const origin = req.headers.origin;
  const configured = (process.env.ALLOWED_ORIGINS || '').split(',').map(v => v.trim()).filter(Boolean);
  return !origin || configured.includes(origin);
}

function rateLimited(req) {
  const key = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const current = requestCounts.get(key);
  if (!current || now - current.start > RATE_LIMIT_WINDOW_MS) {
    requestCounts.set(key, { start: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > RATE_LIMIT_MAX;
}
const ROOT_DIR = __dirname;
const YTDLP_BIN = path.join(ROOT_DIR, 'bin', 'yt-dlp');
const PYTHON_BIN = process.env.PYTHON_BIN || 'python3';

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4'
};

function sanitizeFilename(name) {
  if (!name) return 'youtube_video.mp4';
  let clean = name.replace(/[^a-zA-Z0-9_\-\.\u0980-\u09FF\s]/g, '').trim().replace(/\s+/g, '_');
  if (!clean.toLowerCase().endsWith('.mp4')) {
    clean += '.mp4';
  }
  return clean.substring(0, 80);
}

function extractYouTubeVideoId(url) {
  if (!url) return null;
  const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/);
  return match ? match[1] : null;
}

const decodeSavetube = (enc) => {
  try {
    const secret_key = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    const data = Buffer.from(enc, 'base64');
    const iv = data.slice(0, 16);
    const content = data.slice(16);
    const key = Buffer.from(secret_key, 'hex');
    const decipher = createDecipheriv('aes-128-cbc', key, iv);
    let decrypted = Buffer.concat([decipher.update(content), decipher.final()]);
    return JSON.parse(decrypted.toString());
  } catch (e) {
    return null;
  }
};

async function resolveDirectYouTubeMp4(videoId, preferredQuality = '720') {
  if (!videoId) return null;
  const canonicalUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const qualities = [...new Set([preferredQuality, '480', '360'])];

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const cdnData = await fetchJson('https://media.savetube.vip/api/random-cdn', {}, 5000);
      const cdn = cdnData && cdnData.cdn ? String(cdnData.cdn) : 'cdn403.savetube.vip';
      if (!/^[a-z0-9.-]+\.savetube\.vip$/i.test(cdn)) throw new Error('Untrusted extractor CDN host');

      const infoget = await fetchJson(`https://${cdn}/v2/info`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0 VideoSaver/3.2', 'Referer': 'https://save-tube.com/' },
        body: JSON.stringify({ url: canonicalUrl })
      }, 7000);

      const info = decodeSavetube(infoget.data);
      if (!info || !info.key) continue;

      for (const q of qualities) {
        try {
          const downloadRes = await fetchJson(`https://${cdn}/download`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0 VideoSaver/3.2', 'Referer': 'https://save-tube.com/' },
            body: JSON.stringify({ downloadType: 'video', quality: `${q}`, key: info.key })
          }, 7000);

          if (downloadRes.data && downloadRes.data.downloadUrl) {
            return {
              title: info.title || 'YouTube Video',
              thumbnail: info.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
              duration: info.duration || null,
              quality: `${q}p`,
              downloadUrl: downloadRes.data.downloadUrl
            };
          }
        } catch (_) {}
      }
    } catch (err) {
      console.warn(`[Savetube Attempt ${attempt}] failed:`, err.message);
    }
  }

  // Secondary fallback: @vreden/youtube_scraper
  try {
    const ytScraper = require('@vreden/youtube_scraper');
    const vRes = await ytScraper.ytmp4(canonicalUrl, 720);
    if (vRes && vRes.download && vRes.download.url) {
      return {
        title: (vRes.metadata && vRes.metadata.title) || 'YouTube Video',
        thumbnail: (vRes.metadata && (vRes.metadata.thumbnail || vRes.metadata.image)) || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
        duration: vRes.metadata && vRes.metadata.seconds,
        quality: vRes.download.quality || '720p',
        downloadUrl: vRes.download.url
      };
    }
  } catch (err2) {
    console.warn('[Vreden Scraper Fallback] failed:', err2.message);
  }

  return null;
}

const server = http.createServer(async (req, res) => {
  res.on('error', () => {});

  let parsedUrl;
  try { parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost:3000'}`); }
  catch (_) { res.writeHead(400); res.end('Malformed request URL'); return; }
  const pathname = parsedUrl.pathname;

  // Same-origin by default; configure ALLOWED_ORIGINS for a separately hosted PWA.
  if (!clientAllowed(req)) { res.writeHead(403); res.end('Origin not allowed'); return; }
  if (req.headers.origin) {
    res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');

  if (req.method !== 'GET' && req.method !== 'OPTIONS') { res.writeHead(405, { 'Allow': 'GET, OPTIONS' }); res.end('Method not allowed'); return; }
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // API 1: Extract YouTube metadata and a downloadable stream URL.
  if (pathname === '/api/youtube-info') {
    if (rateLimited(req)) { res.writeHead(429, { 'Retry-After': '60' }); res.end(JSON.stringify({ success: false, error: 'Rate limit exceeded' })); return; }
    const targetUrl = parsedUrl.searchParams.get('url');
    if (!targetUrl || !isValidYouTubeUrl(targetUrl)) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: 'A valid HTTPS YouTube video URL is required' }));
      return;
    }

    const videoId = extractYouTubeVideoId(targetUrl);
    console.log(`[YouTube Info] Processing: ${targetUrl} (Video ID: ${videoId})`);

    try {
      const directResult = await resolveDirectYouTubeMp4(videoId, '720');
      if (directResult && directResult.downloadUrl) {
        const safeName = sanitizeFilename(directResult.title);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          title: directResult.title,
          thumbnail: directResult.thumbnail,
          duration: directResult.duration,
          filename: safeName,
          quality: directResult.quality,
          hdUrl: directResult.downloadUrl,
          sdUrl: directResult.downloadUrl,
          directDownloadUrl: directResult.downloadUrl
        }));
        return;
      }
    } catch (ex) {
      console.warn('[YouTube Info Direct] resolution error:', ex.message);
    }

    // Fallback: oEmbed metadata + stream route
    try {
      let oembedTitle = 'YouTube Video';
      let oembedThumb = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null;
      try {
        const oembedData = await fetchJson(`https://www.youtube.com/oembed?url=${encodeURIComponent(targetUrl)}&format=json`, {}, 4000);
        if (oembedData) {
          oembedTitle = oembedData.title || oembedTitle;
          oembedThumb = oembedData.thumbnail_url || oembedThumb;
        }
      } catch (_) {}

      const safeName = sanitizeFilename(oembedTitle);
      const streamApiUrl = `/api/youtube-stream?url=${encodeURIComponent(targetUrl)}&title=${encodeURIComponent(safeName)}`;

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        title: oembedTitle,
        thumbnail: oembedThumb,
        filename: safeName,
        directDownloadUrl: streamApiUrl,
        hdUrl: streamApiUrl,
        sdUrl: streamApiUrl
      }));
    } catch (parseErr) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: false, error: 'Extraction error' }));
    }
    return;
  }

  // API 2: Direct 1-Click Stream / Download (Clean Direct MP4 Download, ZERO External Sites)
  if (pathname === '/api/youtube-stream') {
    if (rateLimited(req)) { res.writeHead(429, { 'Retry-After': '60' }); res.end('Rate limit exceeded'); return; }
    const targetUrl = parsedUrl.searchParams.get('url');
    const customTitle = parsedUrl.searchParams.get('title');

    if (!targetUrl || !isValidYouTubeUrl(targetUrl)) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('A valid HTTPS YouTube video URL is required');
      return;
    }
    if (activeStreams >= MAX_ACTIVE_STREAMS) { res.writeHead(503, { 'Retry-After': '15' }); res.end('Server is busy. Try again shortly.'); return; }

    const videoId = extractYouTubeVideoId(targetUrl);
    const filename = sanitizeFilename(customTitle || 'video.mp4');
    console.log(`[YouTube Stream] 1-Click direct request for: ${targetUrl} as ${filename}`);

    // Try resolving direct CDN MP4 download URL
    if (videoId) {
      try {
        const directResult = await resolveDirectYouTubeMp4(videoId, '720');
        if (directResult && directResult.downloadUrl) {
          console.log(`[YouTube Stream] Successfully resolved direct CDN URL: ${directResult.downloadUrl}`);
          res.writeHead(302, {
            'Location': directResult.downloadUrl,
            'Cache-Control': 'no-cache'
          });
          res.end();
          return;
        }
      } catch (e) {
        console.warn('[YouTube Stream] Direct resolver error:', e.message);
      }
    }

    // Secondary fallback: yt-dlp direct pipe
    console.log(`[YouTube Stream] Fallback to yt-dlp pipe for: ${targetUrl}`);
    if (!fs.existsSync(YTDLP_BIN)) { res.writeHead(503, { 'Content-Type': 'text/plain' }); res.end('Video extraction engine is not installed on this server.'); return; }
    activeStreams += 1;
    const ytProcess = spawn(PYTHON_BIN, [YTDLP_BIN,
      '--no-playlist', '--no-warnings', '--socket-timeout', '20',
      '--js-runtimes', 'node:node',
      '-f', 'best[ext=mp4]/best',
      targetUrl,
      '-o', '-'
    ], { stdio: ['ignore', 'pipe', 'pipe'] });
    let streamFinished = false;
    const finishStream = () => { if (!streamFinished) { streamFinished = true; activeStreams = Math.max(0, activeStreams - 1); } };

    let hasSentHeaders = false;

    ytProcess.stdout.once('data', (chunk) => {
      if (res.destroyed) { ytProcess.kill('SIGKILL'); return; }
      hasSentHeaders = true;
      res.writeHead(200, {
        'Content-Type': 'video/mp4',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      });
      res.write(chunk);
      ytProcess.stdout.pipe(res);
    });

    ytProcess.stdout.on('error', () => {});
    ytProcess.stderr.on('data', (d) => {
      console.log('[yt-dlp stderr]', d.toString().trim());
    });

    res.on('close', () => {
      if (!res.writableEnded) { try { ytProcess.kill('SIGKILL'); } catch (_) {} }
      finishStream();
    });

    ytProcess.on('close', (code) => {
      finishStream();
      if (!hasSentHeaders && !res.headersSent && !res.destroyed) {
        console.error(`[YouTube Stream] yt-dlp exited with code ${code} without data`);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Could not stream video. Please try again.' }));
      }
    });

    ytProcess.on('error', (err) => {
      finishStream();
      console.error('[Stream Error]', err);
      if (!hasSentHeaders && !res.headersSent && !res.destroyed) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: false, error: 'Server streaming error' }));
      }
    });
    return;
  }

  // Health check
  if (pathname === '/healthz' || pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', time: Date.now() }));
    return;
  }

  // Serve static files
  let decodedPath;
  try { decodedPath = decodeURIComponent(pathname); } catch (_) { res.writeHead(400); res.end('Bad path'); return; }
  const relativePath = decodedPath.replace(/^\/+/, '') || 'index.html';
  const allowedRootFiles = new Set(['index.html', 'manifest.json', 'sw.js']);
  const allowedAssetFiles = new Set([
    'app/src/main/res/drawable/video_saver_icon_1792967630180.jpg',
    'public/icons/icon-192.png',
    'public/icons/icon-512.png'
  ]);
  if (!allowedRootFiles.has(relativePath) && !allowedAssetFiles.has(relativePath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return;
  }
  let filePath = path.resolve(ROOT_DIR, relativePath);
  if (filePath !== ROOT_DIR && !filePath.startsWith(ROOT_DIR + path.sep)) { res.writeHead(403); res.end('Forbidden'); return; }

  // Never expose source files, environment files, package manifests, or build artifacts.
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('File not found');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    const isNoCache = ext === '.html' || ext === '.json' || filePath.endsWith('sw.js');
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': isNoCache ? 'no-cache, no-store, must-revalidate, max-age=0' : 'public, max-age=86400'
    });
    res.end(content);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`VideoSaver Server listening on ${HOST}:${PORT}`);
});

server.on('error', (error) => {
  console.error('[Server startup error]', error);
  process.exitCode = 1;
});
